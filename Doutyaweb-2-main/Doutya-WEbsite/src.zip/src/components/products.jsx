import React, { useState } from 'react';
import XtaartImage from '../assets/Xtaart.jpg'; 
import XortlistImage from '../assets/Xortlist.jpg'; 
import Doutya_RecruitImage from '../assets/Doutya_Recruit.jpg'; 
import Doutya_EngageImage from '../assets/Doutya_Engage.jpg'; 
// Sample product data
const products = [
    { id: 1, src: XtaartImage, alt: 'Product 1', name: 'Xtaart', description: 'Description of Product 1' },
    { id: 2, src: XortlistImage, alt: 'Product 2', name: 'Xortlist', description: 'Description of Product 2' },
    { id: 3, src: Doutya_RecruitImage, alt: 'Product 3', name: 'Doutya Recruit', description: 'Description of Product 3' },
    { id: 4, src: Doutya_EngageImage, alt: 'Product 4', name: 'Doutya Engage', description: 'Description of Product 4' },
];

const ProductSection = () => {
    const [selectedProduct, setSelectedProduct] = useState(null);

    const handleImageClick = (product) => {
        setSelectedProduct(product);
    };

    return (
        <div className="h-screen flex flex-col">
            {/* Top Half: 2 Product Cards */}
            <div className="flex-1 grid grid-cols-2 gap-4 p-4">
                {products.slice(0, 2).map((product) => (
                    <div
                        key={product.id}
                        className="relative group cursor-pointer rounded-lg overflow-hidden border border-gray-300 shadow-lg transition-transform transform hover:scale-105 custom-top-card"
                    >
                        <img
                            src={product.src}
                            alt={product.alt}
                            className="w-full h-full object-cover transition-transform duration-300 transform group-hover:scale-105"
                            onClick={() => handleImageClick(product)}
                        />
                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-opacity duration-300 flex items-center justify-center text-white text-center opacity-0 group-hover:opacity-100">
                            <div className="p-4">
                                <h3 className="text-lg font-semibold">{product.name}</h3>
                                <p className="mt-2 text-sm">{product.description}</p>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Bottom Half: 2 Product Cards */}
            <div className="flex-1 grid grid-cols-2 gap-4 p-4">
                {products.slice(0,2).map((product) => (
                    <div
                        key={product.id}
                        className="relative group cursor-pointer rounded-lg overflow-hidden border border-gray-300 shadow-lg transition-transform transform hover:scale-105 custom-bottom-card"
                    >
                        <img
                            src={product.src}
                            alt={product.alt}
                            className="w-full h-full object-cover transition-transform duration-300 transform group-hover:scale-105"
                            onClick={() => handleImageClick(product)}
                        />
                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-opacity duration-300 flex items-center justify-center text-white text-center opacity-0 group-hover:opacity-100">
                            <div className="p-4">
                                <h3 className="text-lg font-semibold">{product.name}</h3>
                                <p className="mt-2 text-sm">{product.description}</p>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Product Details Modal */}
            {selectedProduct && (
                <div className="fixed inset-0 bg-gray-800 bg-opacity-75 flex items-center justify-center p-4">
                    <div className="bg-white text-black p-8 rounded-lg w-full max-w-lg relative">
                        <button
                            onClick={() => setSelectedProduct(null)}
                            className="absolute top-2 right-2 text-gray-600 hover:text-gray-800 text-xl"
                        >
                            &times;
                        </button>
                        <h2 className="text-2xl mb-4">{selectedProduct.name}</h2>
                        <img
                            src={selectedProduct.src}
                            alt={selectedProduct.alt}
                            className="w-full h-60 object-cover mb-4"
                        />
                        <p>{selectedProduct.description}</p>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ProductSection;
``